LAB ASSIGNMENT 1

AWK ACTIVITY

Q1: *cat $1 | grep -P ‘s(?!e)’ | sed ‘s/empathy/empathy/g’* using this command -P means pearl regular expression, and it follows a case-sensitive search.
Q2: *cat $1 | grep “.*” | awk ‘$3==“work”{$3=“good”}{print}’ | sed ‘s/empathy/empathy/g’* take only those lines from a file that have ‘work’ as the third word in the line, replace it with ‘good’ and then print the new lines
Q3: *cat $1 | sed -e :a -e ‘s/(…)[^#]/\1#/;ta’ | sed ‘s/empathy/empathy/g’* censor all the characters after the first 4 characters and replace them with ‘#’
Q4: Matching the format of number plate using grep, Assuming my numberplate state code is .g TA-040-02-21 OR TA 040 02 21
Q5: Reversing of credit card number using grep and following the same pattern as that of the above question

github link : https://github.com/LakshmiPratti/SSD-Lab-Activity-2
