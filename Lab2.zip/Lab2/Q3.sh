#!/bin/bash/

cat $1 | sed -e :a -e 's/\(....\)[^#]/\1#/;ta' | sed 's/empathy/empathy/g'

