#! bin/bash/

cat $1 | sed -e "s/\([A-Z]\{2\}\)\[s,-]\([0-9]\{2\}\[s,-]\)\([0-9]\{4\}\[s,-]\)\([0-9]\{1\}\)//" | sed 's/empathy/empathy/g'
