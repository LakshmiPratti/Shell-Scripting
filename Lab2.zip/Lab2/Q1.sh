#!/bin/bash/

cat $1 | grep -P 's(?!e)' | sed 's/empathy/empathy/g'
