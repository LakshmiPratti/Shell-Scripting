#!/bin/bash

file="crontab_file" 

re='^[0-9]+$' 

checkCronExpression() {
    IFS=' '
    read -a strarr <<< "$1"
    length=${#strarr[@]}
    if [ $length -ne 6 ]; then
        return 1
    fi
    for item in "${!strarr[@]}"; 
    do
        
        case "$item" in
        0) 
        if ! [[ ${strarr[$item]} =~ $re ]]; then
            if [ "${strarr[$item]}" != "*" ]; then
                return 1
            fi
        else if ((${strarr[$item]#0} < 0 || ${strarr[$item]#0} > 59)); then
            return 1
            fi
        fi
        ;;
        1) 
        if ! [[ ${strarr[$item]} =~ $re ]]; then
            if [ "${strarr[$item]}" != "*" ]; then
                return 1
            fi
        else if ((${strarr[$item]#0} < 0 || ${strarr[$item]#0} > 23)); then
            return 1
            fi
        fi
        ;;
        2) 
        if ! [[ ${strarr[$item]} =~ $re ]]; then
            if [ "${strarr[$item]}" != "*" ]; then
                return 1
            fi
        else if ((${strarr[$item]#0} < 0 || ${strarr[$item]#0} > 31)); then
            return 1
            fi
        fi
        ;;
        3) 
        if ! [[ ${strarr[$item]} =~ $re ]]; then
            if [ "${strarr[$item]}" != "*" ]; then
                return 1
            fi
        else if ((${strarr[$item]#0} < 0 || ${strarr[$item]#0} > 12)); then
            return 1
            fi
        fi
        ;;
        4) 
        if ! [[ ${strarr[$item]} =~ $re ]]; then
            if [ "${strarr[$item]}" != "*" ]; then
                return 1
            fi
        else if ((${strarr[$item]#0} < 0 || ${strarr[$item]#0} > 7)); then
            return 1
            fi
        fi
        ;;
        5)
        # Check if valid command
        if ! command -v ${strarr[$item]} &> /dev/null
        then
            return 1
        fi
        ;;
        esac
    done
    return 0
}

while IFS= read -r line; do
    checkCronExpression "$line"
    result=$?
    if [ $result -eq 1 ]; then
        echo "No"
    else
        echo "Yes"
    fi
done < $file
