#!/bin/bash 
HISTFILE=~/.bash_history
set -o history
history 10 | awk '{i[$2]++}END{for (x in i) print x,i[x] | "sort -r -k2"}'


