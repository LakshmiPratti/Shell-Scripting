#!/bin/bash
file="pid.txt"
ps -a -o pid > $file

while read LINE; 
do 
	Pids=( "${Pids[@]}" "$LINE" )
done < $file

sortedPids=($(sort <<<"${Pids[*]}"))
length=${#sortedPids[@]}

read num
if [ $num -gt $length ]; then
	echo "Requested Values($num) greater than available($length)"
	num=$length
fi
for i in $(seq 1 $num);
do 
	echo ${sortedPids[$i]}
done
