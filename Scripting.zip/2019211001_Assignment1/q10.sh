#!/bin/bash 

read operator

case "$operator" in
	"+") intialize=0
	;;
	"-") intialize=0
	;;
	"*") intialize=1
	;;
	"/") intialize=1
	;;     
esac

read nop

for i in $(seq 1 $nop);
do 
	read operand
	case "$operator" in
	"+")
        intialize=`expr $intialize + $operand` 
        ;;
        "-")
        if [ $i -ne 1 ]; then
            operand=`expr -1 \* $operand`
        fi
        intialize=`expr $intialize + $operand` 
        ;;
        "*")
        intialize=`expr $intialize \* $operand` 
        ;;
        "/")
        if [ $i -ne 1 ]; then
            operand=`echo 'scale=4;' 1/$operand | bc`
        fi
        intialize=`echo 'scale=4;' $intialize \* $operand | bc`
        ;;
    esac
done

echo $intialize

