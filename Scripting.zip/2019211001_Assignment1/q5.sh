#!/bin/bash/

echo -n 
read text
ucase=$( echo $text | sed 's/[^A-Z]//g')
case=$( echo $text | tr '[:upper:]' '[:lower:]')
rev=$(echo $case | rev)
if [ $case == $rev ]; then
	echo "Yes ($ucase is/are upper case but still palindrome)"
else
	echo "No"
fi
