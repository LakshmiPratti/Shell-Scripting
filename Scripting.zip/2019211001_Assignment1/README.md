# ASSIGNMENT 1

## Q1:
b) Creates 5 empty files instead of writing touch lab1.txt lab2.txt.....so on, when file names differ by just number and provided they are in order then inside {} we can specify the start and end points.
```sh
$ touch lab{1..5}.txt
```
### Installation for c part in Q1
c) Install *rename* if not present in your system
```sh
$ sudo apt install rename
```
d) List long format including hidden files.
```sh
$ ls -la
```
List long format with readable file size.
```sh
$ ls -lh
```
Combined both to get desired results
```sh
$ ls -lah
```
e) Gives the full path of the current working directory
```sh
$ $PWD
```
-maxdepth stops the search at a certain depth which is speicified and -type f,d includes only files and directories(folders).
```sh
$ find $PWD -maxdepth 2 -type f,d
```

### Q2:
a) Unscrambling the word and storing all the combinations in a list.
b) To check if word exists as a command.
```sh
$  if command -v <word>
```
Iterated through all the combinations of scrambled words and Terminate the loop as it finds it's first match as we are printing only one match, since each word may have more than one match, e.g; "cat" is also a command and so do "tac" is.
c) Stored all the valid commands and then checked it with the input word.

### Q3:
a) The history command is disabled by default on bash script that's why even history command won't work in .sh file. for its redirection, kindly redirect bash_history file inside the .sh file.
```sh
#!/bin/bash
HISTFILE=~/.bash_history
set -o history 
```
b) For getting the last 10 commands used, we can use:
```sh
$  history | tail
Or
$  history 10
```
c) With the help of awk extracted the command names and with a counter, counted the occurence of each command and then sorted it in reverse order provided the command comes first and the occurence comes next so used -k2 to sort the second field.
```sh
$  awk '{i[$2]++}END{for (x in i) print x,i[x] | "sort -r -k2"}'
```

### Q4:
a) Extracting the data which follows the pattern and storing it in a .txt file.
```sh
$  grep -Eo '[[:alpha:]]+|[0-9.]+' <<<"$s" > ans.txt
```
b) Concatenated the data in the .txt file using cat and printed the output in parenthesis.
```sh
$  echo "($(echo $(cat ans.txt)))"
```

### Q5:
a) ucase variable contains all the capital letter characters of the string.
```sh
ucase=$(echo $text | sed 's/[^A-Z]//g')
```
b) Converted string to lower case by *tr* command
```sh
case=$( echo $text | tr '[:upper:]' '[:lower:]')
```
c) Stored the reverse order of the characters in a variable using *rev* command and lastly compared it with the orginal.
```sh
rev=$(echo $case | rev)
if [ $case == $rev ];
```
### Q6:
a) Setting result to first argument if provided else return error.
```sh
if [ $# -eq 0 ]; then
        echo "Error: Atleast one argument required";
        exit 1
```
b) Regex for checking integer.
```sh
re='^[0-9]+$'
```
c) For calculating the exponential value.
```sh
power()
{
        let result=( $1**$2 )
}
```
d) Ignoring the first argument, iterate over the remaining ones:
```sh
for var in ${@:2}
```

### Q7:
a) file="pid.txt": file where PID's are stored
b) List all the running process Id's: 
```sh
ps -a -o pid > $file
```
c) Reading and saving the values stored in file to array and sorting the ids.

### Q8:
a) Crontab will be written in this file
```sh
file="crontab_file"
```
b) Conditions for Cron that are considered
Min- Minute - 0 through 59
HR - Hour - 0 through 23
Dom - Day of Month - 0 through 31
Mon - Month - 0 through 12
Dow - Day of Week - 0 through 7 (0 and 7 are both Sunday)
CMD - Command - Any command to be executed
c) Return 1 means invalid 0 means valid.

### Q9:
a) Stored string in *str2* by removing spaces.
b) Checked if string contains numbers and followed the conditions asked in the question.
c) #digit: number of digits; #str: length of string.

### Q10:
a) Variables used for:
Operation Type: Operator
Number of operands: nop
Operand1,Operand2.....OperandN: Operand










   
