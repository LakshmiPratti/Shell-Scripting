#!/bin/bash

mkdir Assignment1/
cd Assignment1/
touch lab{1..5}.txt
rename 's/\.txt$/\.c/' *.txt
ls -lah
cd ~
find $PWD -maxdepth 2 -type f,d
cd Assignment1/
locate -br '^lab.txt$'
#ls "$PWD"/*.txt
