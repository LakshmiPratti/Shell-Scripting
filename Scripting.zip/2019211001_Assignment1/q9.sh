#!/bin/bash

read str2 
str=$(echo $str2 | tr -d ' ')
if [[ $str =~ ^[0-9]+$ ]]
then
	strlen=${#str}
	if [ $((strlen)) -gt 1 ]; then
		for i in $(seq $((strlen - 1)) -1 0); do
			digit=${str:$i:1}
			if [ $(((strlen-i) % 2)) -eq 0 ]; then
     			((digit*=2))
     			[ ${#digit} -eq 2 ] && digit=$((${digit:0:1}+${digit:1:1}))
  			fi
  			((sum+=digit))
		done
		if [ $(((sum) % 10)) -eq 0 ]; then
			echo Valid
		else
			echo Invalid
		fi
	else
		echo Invalid
	fi
else
	echo Invalid
fi

