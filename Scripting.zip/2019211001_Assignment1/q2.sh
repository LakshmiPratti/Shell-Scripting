#!/bin/bash 

read string

unscrambledwords=()

scramble() {
	local items="$1"
	local out="$2"
	local i
	[[ "$items" == "" ]] && unscrambledwords+=($out) && return
	for (( i=0; i<${#items}; i++ )) ; do
	scramble "${items:0:i}${items:i+1}" "$out${items:i:1}"
	done
}
scramble $string

validCommands=()

for input in "${unscrambledwords[@]}"
do
	if command -v $input &> /dev/null   
	then
		validCommands+=($input)
	break
	fi
done

validCommandLength=${#validCommands[@]}
if [ $validCommandLength -eq 0 ]; then
	echo "No"
	exit 1
fi

for input in "${validCommands[@]}"
do
	echo "Yes"
	echo $input	
done
