#!bin/bash

read string
s="$string"
echo $string | grep -Eo '[[:alpha:]]+|[0-9.]+' <<< "$s" > ans.txt
echo "($(echo $(cat ans.txt)))"
