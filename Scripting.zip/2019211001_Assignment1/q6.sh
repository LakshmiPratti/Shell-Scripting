#!/bin/bash

if [ $# -eq 0 ]; then
	echo "Error: Atleast one argument required";
	exit 1
else
	result=$1
fi

power()
{
	let result=( $1**$2 )
}

re='^[0-9]+$' 

for var in ${@:2}
do
	if ! [[ $var =~ $re ]] ; then
		echo "Error: $var is not a number";
		exit 1
	fi
	power $result $var
done
echo $result
