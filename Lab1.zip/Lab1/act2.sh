#!/bin/bash
grep -o -i " to " hamlet.txt | wc -l
grep -F " is " hamlet.txt
grep -i -B 2 " bear " hamlet.txt
chmod go-rwx hamlet.txt | chmod 700 hamlet.txt #symbolic and octal#
chmod ugo+rwx hamlet.txt | chmod 777 hamlet.txt  
groups lakshmipratti
chown :lp hamlet.txt
find . -maxdepth 1 -perm -001 -type f

