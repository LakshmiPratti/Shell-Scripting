#!/bin/bash
#!/bin/bash
cal > out1
echo $(date '+%d-%m-%Y')>> out1
cat out1
tail -3 out1
sed '3,7!d' out1 #head -3 out1 | tail +7# 
sed '3,7!d' out1 | wc -l
echo "This day is awesome." >out2
wc -w out2
echo "I am looking forward to the day." >>out2
wc -l out2
awk '{ print $5 }' out1
awk '{for(i=4;i<=9;++i)print $i}' out1
awk '{for(i=3;i<=NF;++i)print $i}' out1
awk '{print $2 " " $4}' out2
